<form action="admin.php" method="post">
  User: <input type="text" name="user"><br>
  Password: <input type="text" name="pass"><br>
  <input type="submit" value="Submit">
</form> 