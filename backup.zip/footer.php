</div>
<div style="clear:both"></div>
<div id="footer">
		
		
		<div id="navigation">
			<div>
				<ul>
					<li class="first"><a href="index.html">help</a></li>
					<li><a href="index.html">about banoful sweets</a></li>
					<li><a href="index.html">banoful sweets talk</a></li>
					<li><a href="index.html">developers</a></li>
					<li><a href="index.html">privacy policy</a></li>
					<li><a href="index.html">terms of use(updated 01/04/2015)</a></li>
				</ul>
				<p>Copyright &copy; 2015-2016 banoful sweets & Co. All rights reserved</p>
			</div>
		</div>
	</div>



</body>


</html>