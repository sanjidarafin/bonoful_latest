<!DOCTYPE html>
<!--header part of banoful-->
<html>
<head>
	<meta charset="UTF-8" />
	<title>Banoful And Co.</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
</head>
<body>
  <?php require_once('header.php') ?>
	<div id="content">
		<h1>Our Concern</h1> <br />
    <p> Banoful & co Ltd is well equipped by modern machinery imported fron Italy & India. By using the most advanced machinery Banaful & Co Ltd now able to produce 15000 ton per year of different kind of confectionary,bakery and snacks itec. Now 2000 work force are employed to meet up the ultimate customer satisfaction along with to smooth the production process. Banoful & co Ltd has the 7 factories in different location in all over the Bangladesh. Good variation and quality is the main strength of the company and it helps the company to become leading national band in Bangladesh. </p>
    
		
    
    
    
    
	</div>
	
	
   <?php require_once('footer.php') ?>
</body>
</html>