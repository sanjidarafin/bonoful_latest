<html>
  <head>
  <title>Banoful And Co|About Us</title>
  </head>
  
  <body>
  <?php require_once("header.php")?>
     <h1>About Our Company</h1>
    
    <p> Like all other creation Banoful & Co. Ltd., has been established with a view to full fill some objectives. The prime object that we uphold is to promote public welfare through supply of pure and nutritious food in absolute hygienic way. 

Keeping in view all our objectives and to frame our dream into the real shape we have established Banoful & Co. Ltd. to produce several types of quality snacks along with differenmt types of sweets, Tea, Mineral water, Chanachur, Laacha semai. various types of Biscuits & Creckers etc. by focusing our attention on adapting technology base, modern plants, professing efficient, integrated operation and pro-actively responding to market demand. 

Banoful & Co. Ltd. will concern its business based on 6 basic elements such as Inexpensive, Delicious, Nutritious, Hygienic, Attractive and Convenient. In order to pursuit nutritious food with good taste and to use ingredient with safely, research activity will be conducted daily in our laboratory. 

We believe, it is not possible to produce excellent product not only by machine alone, but also processing know-how and belief to unit of all staffs mind is important. Taking that in our view we have framed our management to an expertise team going to provide excellent product before the honorable consumer.We have a cherished goal a goal to gear up the progress and prosperity in the food sector which will undoubtedly be a tool for economic development in the country. 
</p>
    <?php require_once("footer.php")?>
  </body>
</html>